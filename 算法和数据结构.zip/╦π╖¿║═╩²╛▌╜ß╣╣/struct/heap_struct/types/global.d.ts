declare type union=string|number|object;
declare type heapData=Array<union>;