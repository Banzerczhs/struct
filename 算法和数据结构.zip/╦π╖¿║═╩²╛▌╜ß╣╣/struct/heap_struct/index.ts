import MaxHeap from "./MaxHeap";

let maxHeap=new MaxHeap([5,2,3,1,6,5,4]);

maxHeap.heapFly(0);

console.log(maxHeap.heapData);

